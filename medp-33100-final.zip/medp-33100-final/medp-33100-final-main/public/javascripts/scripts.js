document.addEventListener('DOMContentLoaded', () => {
    const songContainer = document.querySelector('#song-container');

    // Handle new song submissions
    document.querySelector('#post_form')?.addEventListener('submit', (e) => {
        e.preventDefault();

        const form = e.target;
        const formData = new FormData(form);

        const formDataObject = {
            song: formData.get('song'),
            image_url: formData.get('image_url'),
            memory: formData.get('memory'),
            authorID: '675b554ed8f2c5f28005c51c'
        };

        fetch('/songs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formDataObject)
        }).then(() => {
            console.log('Song added');
        });
    });

    // Filtering functionality
    const filterButtons = document.querySelectorAll('.filter-button');
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const filterType = button.getAttribute('data-tag'); // Get the filter type
            sortSongs(filterType); // Apply the sorting
        });
    });

    // Function to sort songs
    function sortSongs(filterType) {
        const songs = Array.from(document.querySelectorAll('.card')); // Convert NodeList to Array

        if (filterType === 'pop') {
            // Sort by newest (assuming a `createdAt` attribute in ISO format)
            songs.sort((a, b) => new Date(b.querySelector('.createdAt').innerText) - new Date(a.querySelector('.createdAt').innerText));
        } else if (filterType === 'rock') {
            // Sort alphabetically (A-Z)
            songs.sort((a, b) => {
                const titleA = a.querySelector('.song').innerText.toLowerCase();
                const titleB = b.querySelector('.song').innerText.toLowerCase();
                return titleA.localeCompare(titleB);
            });
        } else if (filterType === 'chill') {
            // Sort reverse alphabetically (Z-A)
            songs.sort((a, b) => {
                const titleA = a.querySelector('.song').innerText.toLowerCase();
                const titleB = b.querySelector('.song').innerText.toLowerCase();
                return titleB.localeCompare(titleA);
            });
        }

        // Clear the container and reattach the sorted elements
        songContainer.innerHTML = '';
        songs.forEach(song => songContainer.appendChild(song));
    }

    // Function to handle comments
    document.querySelectorAll('.card').forEach(song => {
        song.querySelector('.comments_form')?.addEventListener('submit', (e) => {
            e.preventDefault();

            const form = e.target;
            const formData = new FormData(form);

            const formDataObject = {
                songID: song.id,
                content: formData.get('content'),
                authorID: '675b554ed8f2c5f28005c51c'
            };

            fetch('/comments', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formDataObject)
            });
        });

        song.querySelector('.edit_button')?.addEventListener('click', () => {
            const memory = song.querySelector('.memory');
            const memoryInput = document.createElement('input');
            memoryInput.value = memory.innerText;
            memoryInput.name = 'memory';
            memoryInput.classList.add('memory_input');

            memory.innerHTML = '';
            memory.appendChild(memoryInput);

            const saveButton = document.createElement('button');
            saveButton.classList.add('save_button');
            saveButton.innerText = 'Save';

            saveButton.addEventListener('click', async () => {
                const newValue = memoryInput.value;

                const updatedSong = {
                    memory: newValue,
                    songID: song.id,
                };

                await fetch('/songs', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(updatedSong)
                });

                memory.innerHTML = '';
                const updatedParagraphEl = document.createElement('p');
                updatedParagraphEl.innerText = newValue;
                memory.appendChild(updatedParagraphEl);

                saveButton.remove();
            });

            song.appendChild(saveButton);
        });

        song.querySelector('.delete_button')?.addEventListener('click', async () => {
            await fetch(`/songs/${song.id}`, {
                method: 'DELETE'
            });

            song.remove();
        });
    });
});
