# MEDP 33100 Final Project

## **Project Overview**

- This web project lets users submit a "soundtrack of their life" by connecting memories with music.
## **Project Members**

- Ziyu Wang
- Aaron Kim

## **Features**

- List the key features of the project (the three distinct types of user interactions).

## **Technologies Used**

- List the technologies and tools used in the project:
    - APIs
    - Libraries
    - Other
 
## **Live Demo**

- Include a link to the live version of the project hosted on Glitch.

## **Credits**

- List any third-party assets used in the project (e.g., sound effects, images, fonts) and provide proper attribution.
- Acknowledge any resources, tutorials, or references you used to help complete the project.

## **Future Enhancements**

- List any future enhancements you would like to make or improve given more time.
